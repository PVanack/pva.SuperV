fn main() -> shadow_rs::SdResult<()> {
    shadow_rs::new()
}
